CREATE DATABASE IF NOT EXISTS `MUSIQUES` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `MUSIQUES`;

CREATE TABLE `ORIGINE` (
  `idartiste` VARCHAR(42),
  `idlocalisation` VARCHAR(42),
  PRIMARY KEY (`idartiste`, `idlocalisation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `A_SORTIE` (
  `idartiste` VARCHAR(42),
  `idalbum` VARCHAR(42),
  PRIMARY KEY (`idartiste`, `idalbum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `GENRE` (
  `idgenres` VARCHAR(42),
  `nomgenre` VARCHAR(42),
  PRIMARY KEY (`idgenres`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `LOCALISATION` (
  `idlocalisation` VARCHAR(42),
  `pays` VARCHAR(42),
  PRIMARY KEY (`idlocalisation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `ARTISTE` (
  `idartiste` VARCHAR(42),
  `nomartiste` VARCHAR(42),
  `bio` VARCHAR(42),
  PRIMARY KEY (`idartiste`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `ALBUM` (
  `idalbum` VARCHAR(42),
  `nomalbum` VARCHAR(42),
  `coveralbum` VARCHAR(42),
  `idartist` VARCHAR(42),
  `date_sortie` VARCHAR(42),
  PRIMARY KEY (`idalbum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `AVOIR_GENRE` (
  `idgenres` VARCHAR(42),
  `idmusique` VARCHAR(42),
  PRIMARY KEY (`idgenres`, `idmusique`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `INTERPRETE` (
  `idartiste` VARCHAR(42),
  `idmusique` VARCHAR(42),
  PRIMARY KEY (`idartiste`, `idmusique`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `DANS_ALBUM` (
  `idalbum` VARCHAR(42),
  `idmusique` VARCHAR(42),
  PRIMARY KEY (`idalbum`, `idmusique`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `MUSIQUE` (
  `idmusique` VARCHAR(42),
  `titre` VARCHAR(42),
  `duree` VARCHAR(42),
  `urlspotify` VARCHAR(42),
  `idspotify` VARCHAR(42),
  `tempo` VARCHAR(42),
  `dansability` VARCHAR(42),
  `energy` VARCHAR(42),
  `popularity` VARCHAR(42),
  PRIMARY KEY (`idmusique`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `DANS_PLAYLIST` (
  `idplaylist` VARCHAR(42),
  `idmusique` VARCHAR(42),
  PRIMARY KEY (`idplaylist`, `idmusique`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `ETRE_CLASSEE` (
  `idmusique` VARCHAR(42),
  `idclassement` VARCHAR(42),
  PRIMARY KEY (`idmusique`, `idclassement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `CLIENT` (
  `idclient` VARCHAR(42),
  `nomclient` VARCHAR(42),
  `prenomclient` VARCHAR(42),
  `mdpclient` VARCHAR(42),
  `mailclient` VARCHAR(42),
  PRIMARY KEY (`idclient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `PLAYLIST` (
  `idplaylist` VARCHAR(42),
  `nomplaylist` VARCHAR(42),
  PRIMARY KEY (`idplaylist`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `CLASSEMENT` (
  `idclassement` VARCHAR(42),
  `nomclassement` VARCHAR(42),
  PRIMARY KEY (`idclassement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `AVOIR_PLAYLIST` (
  `idclient` VARCHAR(42),
  `idplaylist` VARCHAR(42),
  PRIMARY KEY (`idclient`, `idplaylist`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `ORIGINE` ADD FOREIGN KEY (`idlocalisation`) REFERENCES `LOCALISATION` (`idlocalisation`);
ALTER TABLE `ORIGINE` ADD FOREIGN KEY (`idartiste`) REFERENCES `ARTISTE` (`idartiste`);
ALTER TABLE `A_SORTIE` ADD FOREIGN KEY (`idalbum`) REFERENCES `ALBUM` (`idalbum`);
ALTER TABLE `A_SORTIE` ADD FOREIGN KEY (`idartiste`) REFERENCES `ARTISTE` (`idartiste`);
ALTER TABLE `AVOIR_GENRE` ADD FOREIGN KEY (`idmusique`) REFERENCES `MUSIQUE` (`idmusique`);
ALTER TABLE `AVOIR_GENRE` ADD FOREIGN KEY (`idgenres`) REFERENCES `GENRE` (`idgenres`);
ALTER TABLE `INTERPRETE` ADD FOREIGN KEY (`idmusique`) REFERENCES `MUSIQUE` (`idmusique`);
ALTER TABLE `INTERPRETE` ADD FOREIGN KEY (`idartiste`) REFERENCES `ARTISTE` (`idartiste`);
ALTER TABLE `DANS_ALBUM` ADD FOREIGN KEY (`idmusique`) REFERENCES `MUSIQUE` (`idmusique`);
ALTER TABLE `DANS_ALBUM` ADD FOREIGN KEY (`idalbum`) REFERENCES `ALBUM` (`idalbum`);
ALTER TABLE `DANS_PLAYLIST` ADD FOREIGN KEY (`idmusique`) REFERENCES `MUSIQUE` (`idmusique`);
ALTER TABLE `DANS_PLAYLIST` ADD FOREIGN KEY (`idplaylist`) REFERENCES `PLAYLIST` (`idplaylist`);
ALTER TABLE `ETRE_CLASSEE` ADD FOREIGN KEY (`idclassement`) REFERENCES `CLASSEMENT` (`idclassement`);
ALTER TABLE `ETRE_CLASSEE` ADD FOREIGN KEY (`idmusique`) REFERENCES `MUSIQUE` (`idmusique`);
ALTER TABLE `AVOIR_PLAYLIST` ADD FOREIGN KEY (`idplaylist`) REFERENCES `PLAYLIST` (`idplaylist`);
ALTER TABLE `AVOIR_PLAYLIST` ADD FOREIGN KEY (`idclient`) REFERENCES `CLIENT` (`idclient`);